const userController = {};

userController.createUser = async () => {};
module.exports = userController;
