const userController = {};

userController.createUser = module.exports = userController;
