const userController = {};

userController.createUser = async (req, res) => {};
module.exports = userController;
