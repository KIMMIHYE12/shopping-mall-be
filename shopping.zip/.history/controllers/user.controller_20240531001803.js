const userController = {};

module.exports = router;
