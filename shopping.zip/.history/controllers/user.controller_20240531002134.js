const User = require("../models/User");

const userController = {};

userController.createUser = async (req, res) => {
  try {
    let { email, password, name } = req.body;
    const user = await User.findOne({ email });
  } catch (error) {
    res.status(400).json({ staus: "fail", error: error.message });
  }
};

module.exports = userController;
