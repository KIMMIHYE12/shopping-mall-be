const userController = {};

userController.createUser = async (req, res) => {
  try {
  } catch (error) {
    res.status(400).json({ staus: "fail", error: error.message });
  }
};

module.exports = userController;
