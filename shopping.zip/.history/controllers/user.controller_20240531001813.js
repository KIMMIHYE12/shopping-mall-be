const userController = {};

module.exports = userController;
