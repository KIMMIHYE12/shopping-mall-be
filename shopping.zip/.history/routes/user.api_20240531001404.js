const express = require("express");
const router = express.Router();

router.post("/", userController.creatUser);

module.exports = router;
