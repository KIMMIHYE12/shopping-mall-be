const mongoose = require("mongoose");
const User = require("./User");
const Product = require("./Product");
const Schema = mongoose.Schema;
const orderSchema = Schema(
  {
    shipTo: {
      type: String,
      required: true,
    },
    contact: {
      type: String,
      required: true,
    },
    userId: { type: mongoose.ObjectId, ref: Product },
    items: [
      { product: { type: mongoose.ObjectId, ref: Product } },
      { size: { type: mongoose.ObjectId, ref: Cart } },
      { qty: { type: mongoose.ObjectId, ref: Cart } },
    ],
  },
  { timestamps: true }
);
odrderSchema.methods.toJSON = function () {
  const obj = this._doc;
  delete obj.__v;
  delete obj.updateAt;
  delete obj.createAt;
  return obj;
};

const Order = mongoose.model("Order", orderSchema);
module.exports = Order;
