const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const productSchema = Schema({}, { timestamps: true });
productSchema.methods.toJSON = function () {
  const obj = this._doc;
  delete obj.__v;
  delete obj.updateAt;
  delete obj.createAt;
  return obj;
};

const User = mongoose.model("User", userSchema);
module.exports = User;
