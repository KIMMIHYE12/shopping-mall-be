const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const productSchema = Schema({
  {sku: {type: String, required: true, unique:true},
name: {type: String, required: true}}
}, { timestamps: true });
productSchema.methods.toJSON = function () {
  const obj = this._doc;
  delete obj.__v;
  delete obj.updateAt;
  delete obj.createAt;
  return obj;
};

const Procuct = mongoose.model("Product", productSchema);
module.exports = Product;
